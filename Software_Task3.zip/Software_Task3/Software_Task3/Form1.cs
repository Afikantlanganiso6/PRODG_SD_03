﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Software_Task3
{
    public partial class Form1 : Form
    {
        private List<Contact> contacts;

        public Form1()
        {
            InitializeComponent();
            contacts = new List<Contact>();
        }

        private void buttonAdd_Click(object sender, EventArgs e)
        {
            string name = textBoxName.Text;
            string phone = textBoxPhone.Text;
            string email = textBoxEmail.Text;

            contacts.Add(new Contact(name, phone, email));
            RefreshDataGridView();
            ClearTextBoxes();
        }

        private void buttonView_Click(object sender, EventArgs e)
        {
            RefreshDataGridView();
        }

        private void buttonEdit_Click(object sender, EventArgs e)
        {
            if (dataGridViewContacts.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridViewContacts.SelectedRows[0].Index;
                string name = textBoxName.Text;
                string phone = textBoxPhone.Text;
                string email = textBoxEmail.Text;

                contacts[selectedIndex] = new Contact(name, phone, email);
                RefreshDataGridView();
                ClearTextBoxes();
            }
            else
            {
                MessageBox.Show("Select a contact to edit.");
            }
        }

        private void buttonDelete_Click(object sender, EventArgs e)
        {
            if (dataGridViewContacts.SelectedRows.Count > 0)
            {
                int selectedIndex = dataGridViewContacts.SelectedRows[0].Index;
                contacts.RemoveAt(selectedIndex);
                RefreshDataGridView();
                ClearTextBoxes();
            }
            else
            {
                MessageBox.Show("Select a contact to delete.");
            }
        }

        private void RefreshDataGridView()
        {
            dataGridViewContacts.DataSource = null;
            dataGridViewContacts.DataSource = contacts;
        }

        private void ClearTextBoxes()
        {
            textBoxName.Text = "";
            textBoxPhone.Text = "";
            textBoxEmail.Text = "";
        }
    }
}

